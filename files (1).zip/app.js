/* Extra Mix — app shell: theme, language, header/footer, i18n */
(function () {
  const S = window.SITE;

  function getLang() { return localStorage.getItem("em-lang") || "ar"; }
  function getTheme() { return localStorage.getItem("em-theme") || "dark"; }

  function t(key) {
    const lang = getLang();
    return (S.translations[lang] && S.translations[lang][key]) || key;
  }
  window.t = t;
  window.currentLang = getLang;

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("em-theme", theme);
  }

  function applyLang(lang) {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    localStorage.setItem("em-lang", lang);
  }

  function applyI18n() {
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      el.textContent = t(el.getAttribute("data-i18n"));
    });
    document.querySelectorAll("[data-i18n-attr]").forEach((el) => {
      const [attr, key] = el.getAttribute("data-i18n-attr").split(":");
      el.setAttribute(attr, t(key));
    });
    const themeBtn = document.getElementById("themeToggle");
    if (themeBtn) {
      const theme = getTheme();
      themeBtn.querySelector(".icon-btn-label").textContent =
        theme === "dark" ? t("theme_light") : t("theme_dark");
    }
  }

  function activeNavKey() {
    const file = (location.pathname.split("/").pop() || "index.html").split("?")[0];
    if (file.startsWith("product") && file !== "products.html") return "products";
    if (file === "products.html") return "products";
    if (file === "projects.html") return "projects";
    if (file === "about.html") return "about";
    return "home";
  }

  function buildHeader() {
    const active = activeNavKey();
    const navHtml = S.nav
      .map(
        (n) =>
          `<a href="${n.href}" class="${n.key === active ? "active" : ""}" data-i18n="nav_${n.key}"></a>`
      )
      .join("");
    return `
    <div class="container">
      <a href="index.html" class="brand">
        <img src="${S.logo}" alt="${S.brand}" />
        <span>${S.brand}</span>
      </a>
      <nav class="main-nav" id="mainNav">${navHtml}</nav>
      <div class="header-actions">
        <button class="icon-btn" id="langToggle" type="button">
          <span data-i18n="lang_switch"></span>
        </button>
        <button class="icon-btn" id="themeToggle" type="button">
          <span class="icon-btn-label"></span>
        </button>
        <button class="nav-toggle" id="navToggle" type="button" aria-label="menu">☰</button>
      </div>
    </div>`;
  }

  function buildFooter() {
    const catLinks = S.products
      .map((p) => `<li><a href="product.html?slug=${p.slug}" class="prod-name" data-slug="${p.slug}"></a></li>`)
      .join("");
    return `
    <div class="container">
      <div class="footer-grid">
        <div>
          <div class="brand" style="margin-bottom:14px;">
            <img src="${S.logo}" alt="${S.brand}" />
            <span>${S.brand}</span>
          </div>
          <p data-i18n="footer_about_d" style="color:var(--text-muted);font-size:.92rem;max-width:38ch;"></p>
        </div>
        <div>
          <h4 data-i18n="footer_links"></h4>
          <ul>
            <li><a href="index.html" data-i18n="nav_home"></a></li>
            <li><a href="products.html" data-i18n="nav_products"></a></li>
            <li><a href="projects.html" data-i18n="nav_projects"></a></li>
            <li><a href="about.html" data-i18n="nav_about"></a></li>
          </ul>
        </div>
        <div>
          <h4 data-i18n="footer_categories"></h4>
          <ul>${catLinks}</ul>
        </div>
        <div>
          <h4 data-i18n="footer_contact"></h4>
          <ul class="mono" style="font-size:.86rem;color:var(--text-muted);">
            <li>${S.site.phone}</li>
            <li>${S.site.email}</li>
            <li class="addr"></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© <span id="year"></span> ${S.brand} — <span data-i18n="rights"></span></span>
        <span class="mono">Damascus, Syria</span>
      </div>
    </div>`;
  }

  function fillFooterDynamic() {
    const lang = getLang();
    document.querySelectorAll(".prod-name").forEach((el) => {
      const p = S.products.find((x) => x.slug === el.dataset.slug);
      if (p) el.textContent = p.category[lang];
    });
    const addr = document.querySelector(".addr");
    if (addr) addr.textContent = S.site.address[lang];
    const y = document.getElementById("year");
    if (y) y.textContent = new Date().getFullYear();
  }

  function wireControls() {
    const langBtn = document.getElementById("langToggle");
    if (langBtn) {
      langBtn.addEventListener("click", () => {
        applyLang(getLang() === "ar" ? "en" : "ar");
        refresh();
      });
    }
    const themeBtn = document.getElementById("themeToggle");
    if (themeBtn) {
      themeBtn.addEventListener("click", () => {
        applyTheme(getTheme() === "dark" ? "light" : "dark");
        applyI18n();
      });
    }
    const navToggle = document.getElementById("navToggle");
    if (navToggle) {
      navToggle.addEventListener("click", () => {
        document.getElementById("mainNav").classList.toggle("open");
      });
    }
  }

  function refresh() {
    applyI18n();
    fillFooterDynamic();
    document.dispatchEvent(new CustomEvent("site:refresh", { detail: { lang: getLang() } }));
  }

  function mount() {
    applyTheme(getTheme());
    applyLang(getLang());

    const headerEl = document.getElementById("site-header");
    const footerEl = document.getElementById("site-footer");
    if (headerEl) headerEl.innerHTML = buildHeader();
    if (footerEl) footerEl.innerHTML = buildFooter();

    wireControls();
    refresh();
    document.dispatchEvent(new CustomEvent("site:ready", { detail: { lang: getLang() } }));
  }

  document.addEventListener("DOMContentLoaded", mount);
})();
